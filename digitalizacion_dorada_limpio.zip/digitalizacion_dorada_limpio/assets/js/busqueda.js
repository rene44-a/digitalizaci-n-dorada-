const inputBusqueda = document.querySelector("#inputBusqueda");
const tarjetasBusqueda = document.querySelectorAll(".tarjeta");
const tituloBusqueda = document.querySelector(".seccion-titulo h2");

function buscarTarjetas() {
    const textoBusqueda = inputBusqueda.value.toLowerCase().trim();

    if (textoBusqueda === "") {
        tituloBusqueda.textContent = "Herramientas";

        tarjetasBusqueda.forEach(tarjeta => {
            tarjeta.style.display = "";
        });

        return;
    }

    tituloBusqueda.textContent = "Resultados de búsqueda";

    tarjetasBusqueda.forEach(tarjeta => {
        const textoTarjeta = tarjeta.textContent.toLowerCase();

        if (textoTarjeta.includes(textoBusqueda)) {
            tarjeta.style.display = "";
        } else {
            tarjeta.style.display = "none";
        }
    });
}

inputBusqueda.addEventListener("keyup", buscarTarjetas);