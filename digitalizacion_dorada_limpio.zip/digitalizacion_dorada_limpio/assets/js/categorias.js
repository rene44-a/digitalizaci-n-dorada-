const categorias = document.querySelectorAll(".categoria");
const tarjetas = document.querySelectorAll(".tarjeta");
const tituloSeccion = document.querySelector(".seccion-titulo h2");
const botonesFiltro = document.querySelectorAll(".filtros button");

// Filtro por categorías
categorias.forEach(categoria => {
    categoria.addEventListener("click", () => {
        const categoriaSeleccionada = categoria.dataset.categoria;
        const nombreCategoria = categoria.textContent.trim();

        categorias.forEach(cat => cat.classList.remove("activa"));
        categoria.classList.add("activa");

        botonesFiltro.forEach(btn => btn.classList.remove("activo"));
        botonesFiltro[0].classList.add("activo"); // deja activo "Todas"

        tituloSeccion.textContent = nombreCategoria;

        tarjetas.forEach(tarjeta => {
            const categoriaTarjeta = tarjeta.dataset.categoria;
            const esRecomendada = tarjeta.dataset.recomendada;

            if (categoriaSeleccionada === "recomendadas") {
                if (esRecomendada === "si") {
                    tarjeta.style.display = "";
                } else {
                    tarjeta.style.display = "none";
                }
            } else if (categoriaTarjeta === categoriaSeleccionada) {
                tarjeta.style.display = "";
            } else {
                tarjeta.style.display = "none";
            }
        });
    });
});

// Filtro por dificultad
botonesFiltro.forEach(boton => {
    boton.addEventListener("click", () => {
        const dificultadSeleccionada = boton.dataset.dificultad;

        botonesFiltro.forEach(btn => btn.classList.remove("activo"));
        boton.classList.add("activo");

        categorias.forEach(cat => cat.classList.remove("activa"));

        if (dificultadSeleccionada === "todas") {
            tituloSeccion.textContent = "Todas las herramientas";

            tarjetas.forEach(tarjeta => {
                tarjeta.style.display = "";
            });
        } else {
            tituloSeccion.textContent = "Herramientas " + boton.textContent.trim();

            tarjetas.forEach(tarjeta => {
                const dificultadTarjeta = tarjeta.dataset.dificultad;

                if (dificultadTarjeta === dificultadSeleccionada) {
                    tarjeta.style.display = "";
                } else {
                    tarjeta.style.display = "none";
                }
            });
        }
    });
});